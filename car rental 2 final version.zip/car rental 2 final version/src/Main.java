
public class Main {
    public static void main(String[] args) {
        Application application = new Application();
        application.start();

    }
}