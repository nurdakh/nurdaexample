public interface ISpeedLock {
    void speedLock (boolean isOn);

}
